﻿using AtputharasaAgachanLB_295.Klassen;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace AtputharasaAgachanLB_295.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
   
    public class InventarController : ControllerBase
    {
        private readonly InventarContext _dbContext;

        public InventarController(InventarContext dbContext)
        {
            _dbContext = dbContext;

        }

        [HttpGet]
        
        public async Task<ActionResult<IEnumerable<InventarList>>> GetItems()
        {

            if (_dbContext.InventarLists == null)
            {
                return NotFound();
            }
            return await _dbContext.InventarLists.ToListAsync();
        }

        [HttpGet("{id}")]
        
        public async Task<ActionResult<InventarList>> GetItem(int id)
        {
            if (_dbContext.InventarLists == null)
            {
                return NotFound();
            }
            var item = await _dbContext.InventarLists.FindAsync(id);
            if (item == null)
            {
                return NotFound();
            }
            return item;
        }

        [HttpPost]
        

        public async Task<ActionResult<InventarList>> PostItem([FromBody] InventarList item)
        {
            _dbContext.InventarLists.Add(item);
            await _dbContext.SaveChangesAsync();
            return CreatedAtAction(nameof(GetItem), new { id = item.ID }, item);

        }

        [HttpPut]
        
        public async Task<ActionResult<InventarList>> PutItem(int id, [FromBody] InventarList item)
        {
            if (id != item.ID)
            {
                return BadRequest();
            }
            _dbContext.Entry(item).State = EntityState.Modified;

            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ItemInStock(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Ok();
        }

        private bool ItemInStock(int id)
        {
            return (_dbContext.InventarLists?.Any(x => x.ID == id)).GetValueOrDefault();
        }

        [HttpDelete("{id}")]

        public async Task<ActionResult> DeleteItem(int id)
        {
            if (_dbContext.InventarLists == null)
            {
                return NotFound();
            }
            var item = await _dbContext.InventarLists.FindAsync(id);
            if (item == null)
            {
                return NotFound();
            }
            _dbContext.InventarLists.Remove(item);

            await _dbContext.SaveChangesAsync();
            return Ok();
        }
    }
}