﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace AtputharasaAgachanLB_295.Klassen
{
    
    public class InventarContext : IdentityDbContext
    {
        public InventarContext(DbContextOptions<InventarContext> options) : base(options)
        {
            
        }

        public DbSet<InventarList> InventarLists { get; set; }


    }
}
