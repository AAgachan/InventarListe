﻿namespace AtputharasaAgachanLB_295.Klassen
{
    public class InventarList
    {
        public int ID { get; set; }
        public string? InventoryItem { get; set; }
        public string? ItemLocation { get; set; }
        public int inStock { get; set; }
    }
}
